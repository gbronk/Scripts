# The Code that Predicts the Future! The Future!
# Gabriel Bronk, PhD
# 2020

# This Python code loads patient data and uses it to predict whether patients
# will get sepsis. This code is inteded for teaching college or advanced
# high school students how to do machine learning (using the specific machine
# learning example of a generalized linear model). To run the code, make sure
# to download all of the other files in this folder, and then you can hit "Run"
# to see the results of the code.


#1 - Load Python modules:
import numpy
import pandas 
import statsmodels.api as StatsModelsModule
from scipy import stats
from matplotlib import pyplot 
from numpy import arange
from numpy import zeros

#2 - Define certain numbers and arrays that we will need later:
ArrayOfCutOffs = arange(0,0.4,0.05)
NumberOfCutOffs = len(ArrayOfCutOffs)
NumberOfTimes = 24
ArrayOfSensitivities = zeros((NumberOfTimes,NumberOfCutOffs))
ArrayOfSpecificities = zeros((NumberOfTimes,NumberOfCutOffs))
PrintResults = 0

#3 - Load data, and let's make a separate table for the sepsis outcomes: 
DataTable = pandas.read_csv("PatientData.txt",sep='\t')
SepsisOutcomes = DataTable[['SepsisOrNot']]

#4 - Use a "for loop" to loop through the data for each time point:
TimeIndex = 0
for Time in arange(1,NumberOfTimes+1):
    BodyMeasurements = DataTable.iloc[:,Time:673:NumberOfTimes]

    #5 - Adjust data, which will make analysis easier:
    BodyMeasurementAverages = BodyMeasurements.mean(axis = 0)
    BodyMeasurementStandardDeviations = BodyMeasurements.std(axis = 0)
    AdjustedBodyMeasurements = (BodyMeasurements - BodyMeasurementAverages)/BodyMeasurementStandardDeviations

    #6 - Add a column of ones to the AdjustedBodyMeasurements table:
    # (since that's just a silly thing required for using the Stats Models Module)
    NumberOfPatients = len(AdjustedBodyMeasurements)
    OnesArray = [1]*NumberOfPatients
    AdjustedBodyMeasurements['Constant'] = OnesArray

    #7 - Split the data into training data and test data: 
    N = round(0.8*NumberOfPatients)
    BodyMeasurementsForTraining = AdjustedBodyMeasurements.iloc[0:N,:]
    SepsisOutcomesForTraining = SepsisOutcomes.iloc[0:N,:]

    BodyMeasurementsForTesting = AdjustedBodyMeasurements.iloc[N:(NumberOfPatients+1),:]
    SepsisOutcomesForTesting = SepsisOutcomes.iloc[N:(NumberOfPatients+1),:]

    #8 - Fit the model to the data:
    OutputFromStatsModels = StatsModelsModule.GLM(SepsisOutcomesForTraining, BodyMeasurementsForTraining, family=StatsModelsModule.families.Binomial())
    FittedModel = OutputFromStatsModels.fit()
    if PrintResults == 1:
        print(FittedModel.summary())

    #9 - Use the fitted model to predict the outcome for other patients:
    PredictedSepsisOutcomes = FittedModel.predict(BodyMeasurementsForTesting)

    #10 - For each cut-off, determine how accurate the model's predictions are:
    CutOffIndex = 0
    for CutOff in ArrayOfCutOffs:
        CorrectlyPredictedSickPeople = 0
        CorrectlyPredictedHealthyPeople = 0
        TotalNumberOfSickPeople = 0
        TotalNumberOfHealthyPeople = 0

        LengthOfTestingData = len(SepsisOutcomesForTesting)
        for PatientNumber in arange(0,LengthOfTestingData):
            RealOutcome = SepsisOutcomesForTesting.iloc[PatientNumber][0]
            PredictedOutcome = PredictedSepsisOutcomes.iloc[PatientNumber]
            if RealOutcome == 1:
                TotalNumberOfSickPeople = TotalNumberOfSickPeople + 1
                if PredictedOutcome > CutOff:
                    CorrectlyPredictedSickPeople = CorrectlyPredictedSickPeople + 1
            if RealOutcome == 0:
                TotalNumberOfHealthyPeople = TotalNumberOfHealthyPeople + 1 
                if PredictedOutcome < CutOff:
                    CorrectlyPredictedHealthyPeople = CorrectlyPredictedHealthyPeople + 1
         
        Sensitivity = (CorrectlyPredictedSickPeople/TotalNumberOfSickPeople)*100
        Specificity = (CorrectlyPredictedHealthyPeople/TotalNumberOfHealthyPeople)*100
          
        ArrayOfSensitivities[TimeIndex,CutOffIndex] = Sensitivity
        ArrayOfSpecificities[TimeIndex,CutOffIndex] = Specificity 
        
        CutOffIndex = CutOffIndex + 1

    TimeIndex = TimeIndex + 1


print(ArrayOfSensitivities)
print(ArrayOfSpecificities)

